package com.example.smarttrushbinmonitoring;

import android.os.Bundle;

import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

public class DustLevelActivity extends AppCompatActivity {

    private ProgressBar dustMeter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dust_level);



        // Dummy data for dust level (0 to 100)
        int dustLevel = 75;

        // Update the progress bar with the dust level
        dustMeter.setProgress(dustLevel);
    }
}
