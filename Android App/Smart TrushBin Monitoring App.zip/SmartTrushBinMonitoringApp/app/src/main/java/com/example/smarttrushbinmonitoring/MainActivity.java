package com.example.smarttrushbinmonitoring;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView fillLevelTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fillLevelTextView = findViewById(R.id.fillLevelTextView);
        Button checkButton = findViewById(R.id.checkButton);

        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // For demo purposes, generate a random fill level (0-100)
                int fillLevel = new Random().nextInt(101);
                updateFillLevel(fillLevel);
            }
        });
    }

    private void updateFillLevel(int fillLevel) {
        fillLevelTextView.setText("Fill Level: " + fillLevel + "%");
    }
}
